require('dotenv').config();
const db = require('./db');
const { Event, User, Interest } = require('./models');

const TAGS = ['IT', 'Дизайн', 'Маркетинг', 'Спорт', 'Музыка', 'Кино', 'Книги', 'Путешествия', 'Кулинария', 'Фотография'];

async function seed() {
  await db.sync({ force: true });

  // Мероприятие с кодом 123456
  const event = await Event.create({
    title: 'PROD Хакатон Минск 2026',
    start_date: '2026-05-17',
    end_date: '2026-05-18',
    description: 'Главное IT-событие года! Нетворкинг, лекции, хакатон.',
    tags: TAGS,
    organizerId: 'org-001',
    accessCode: '123456',
    expires_at: new Date('2026-05-19'),
  });
  console.log(`✅ Мероприятие создано: ${event.title} (код: ${event.accessCode})`);

  // 10 участников
  const participants = [
    { firstName: 'Анна', middleName: 'Кузнецова', age: 26, profession: 'Frontend-разработчик', hobbies: ['IT', 'Дизайн', 'Музыка'], contact: '@anna_dev' },
    { firstName: 'Дмитрий', middleName: 'Соколов', age: 31, profession: 'Backend-разработчик', hobbies: ['IT', 'Спорт', 'Книги'], contact: '@dima_back' },
    { firstName: 'Елена', middleName: 'Морозова', age: 29, profession: 'Продакт-менеджер', hobbies: ['Маркетинг', 'Путешествия', 'Фотография'], contact: '@elena_pm' },
    { firstName: 'Максим', middleName: '', age: 34, profession: 'Data Scientist', hobbies: ['IT', 'Кино', 'Путешествия'], contact: '@max_ds' },
    { firstName: 'Ольга', middleName: 'Васильева', age: 27, profession: 'UX/UI-дизайнер', hobbies: ['Дизайн', 'Музыка', 'Кулинария'], contact: '@olga_design' },
    { firstName: 'Иван', middleName: 'Петров', age: 36, profession: 'DevOps-инженер', hobbies: ['IT', 'Спорт', 'Книги'], contact: '@ivan_devops' },
    { firstName: 'Мария', middleName: 'Сидорова', age: 25, profession: 'QA-инженер', hobbies: ['IT', 'Кино', 'Кулинария'], contact: '@maria_qa' },
    { firstName: 'Антон', middleName: '', age: 32, profession: 'Mobile-разработчик', hobbies: ['IT', 'Музыка', 'Путешествия'], contact: '@anton_mobile' },
    { firstName: 'Ксения', middleName: 'Новикова', age: 28, profession: 'Маркетолог', hobbies: ['Маркетинг', 'Фотография', 'Книги'], contact: '@kseniya_marketing' },
    { firstName: 'Владислав', middleName: 'Романов', age: 35, profession: 'CTO', hobbies: ['IT', 'Спорт', 'Путешествия'], contact: '@vlad_cto' },
  ];

  const createdUsers = [];
  for (const p of participants) {
    const user = await User.create({ ...p, eventId: event.id });
    createdUsers.push(user);
  }
  console.log(`✅ Добавлено ${createdUsers.length} участников`);

  // ──────────────────────────────────────────────────────────────────────────
  // 👤 ДЕМО-ПОЛЬЗОВАТЕЛЬ ПО УМОЛЧАНИЮ (только для редактирования, не добавлять новых)
  // ──────────────────────────────────────────────────────────────────────────
  const defaultUser = await User.create({
    firstName: 'Демо',
    middleName: 'Пользователь',
    age: 25,
    profession: 'Тестировщик',
    hobbies: ['IT', 'Спорт', 'Книги'],
    contact: '@demo_user',
    eventId: event.id,
    isGuest: false,
  });
  console.log(`✅ Демо-пользователь: ${defaultUser.firstName} (id: ${defaultUser.id}, contact: ${defaultUser.contact})`);

  // Сохраняем ID демо-пользователя в файл для удобства
  const fs = require('fs');
  fs.writeFileSync('/tmp/demo_user_id.txt', String(defaultUser.id));
  console.log(`📝 ID демо-пользователя сохранён в /tmp/demo_user_id.txt`);

  // Создаём несколько взаимных лайков для демонстрации
  await Interest.create({ fromUserId: createdUsers[0].id, toUserId: createdUsers[1].id, status: 'accepted' });
  await Interest.create({ fromUserId: createdUsers[1].id, toUserId: createdUsers[0].id, status: 'accepted' });
  await Interest.create({ fromUserId: createdUsers[2].id, toUserId: createdUsers[3].id, status: 'pending' });
  await Interest.create({ fromUserId: createdUsers[4].id, toUserId: createdUsers[5].id, status: 'pending' });
  await Interest.create({ fromUserId: createdUsers[6].id, toUserId: createdUsers[7].id, status: 'pending' });
  await Interest.create({ fromUserId: createdUsers[8].id, toUserId: createdUsers[9].id, status: 'pending' });
  
  // Демо-пользователь лайкает нескольких участников
  await Interest.create({ fromUserId: defaultUser.id, toUserId: createdUsers[0].id, status: 'pending' });
  await Interest.create({ fromUserId: defaultUser.id, toUserId: createdUsers[2].id, status: 'pending' });
  await Interest.create({ fromUserId: defaultUser.id, toUserId: createdUsers[4].id, status: 'pending' });
  console.log(`✅ Демо-пользователь отправил 3 запроса`);

  console.log('🎉 Seed завершён успешно!');
  console.log(`🔑 Демо-пользователь для входа: contact = @demo_user`);
  console.log(`🔑 Код мероприятия: 123456`);
  
  process.exit(0);
}

seed();