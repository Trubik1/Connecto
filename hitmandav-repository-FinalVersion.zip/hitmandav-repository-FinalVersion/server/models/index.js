const User = require('./User');
const Event = require('./Event');
const Interest = require('./Interest');

Event.hasMany(User, { foreignKey: 'eventId' });
User.belongsTo(Event, { foreignKey: 'eventId' });

Interest.belongsTo(User, { as: 'fromUser', foreignKey: 'fromUserId' });
Interest.belongsTo(User, { as: 'toUser',   foreignKey: 'toUserId' });
User.hasMany(Interest, { as: 'sentInterests',     foreignKey: 'fromUserId' });
User.hasMany(Interest, { as: 'receivedInterests', foreignKey: 'toUserId'   });
Event.hasMany(Interest, { foreignKey: 'eventId' });

module.exports = { User, Event, Interest };
