import { useState, useEffect, useRef } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';

export default function Requests() {
  const userId = localStorage.getItem('currentUserId');
  const [requests, setRequests] = useState<any[]>([]);
  const timersRef = useRef<Map<number, ReturnType<typeof setTimeout>>>(new Map());

  useEffect(() => {
    if (userId) {
      api.get(`/users/${userId}/incoming-requests`).then(res => setRequests(res.data));
    }
  }, [userId]);

  // Определяем eventId пользователя (тестовое мероприятие имеет id 1)
  const [isTestEvent, setIsTestEvent] = useState(false);
  useEffect(() => {
    if (userId) {
      api.get(`/users/${userId}`).then(res => {
        if (res.data.eventId === 1) setIsTestEvent(true);
      }).catch(() => {});
    }
  }, [userId]);

  useEffect(() => {
    if (!isTestEvent) return; // автолайк только для тестового мероприятия
    requests.forEach(req => {
      if (!timersRef.current.has(req.id)) {
        const timer = setTimeout(() => {
          respond(req.id, 'accept');
        }, 5000);
        timersRef.current.set(req.id, timer);
        toast(`🤖 Запрос от ${req.fromUser?.firstName || req.fromUser?.name} будет автоматически принят через 5 секунд`, { duration: 5000, icon: '⏳' });
      }
    });
    return () => {
      timersRef.current.forEach(timer => clearTimeout(timer));
      timersRef.current.clear();
    };
  }, [requests, isTestEvent]);

  const respond = async (interestId: number, action: 'accept' | 'reject') => {
    try {
      await api.put('/users/interest', { interestId, action });
      toast.success(action === 'accept' ? '💚 Запрос принят! Контакт открыт' : '❌ Запрос отклонён');
      setRequests(prev => prev.filter(r => r.id !== interestId));
      if (timersRef.current.has(interestId)) {
        clearTimeout(timersRef.current.get(interestId)!);
        timersRef.current.delete(interestId);
      }
    } catch (err) {
      toast.error('Ошибка при обработке запроса');
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-4 page-enter">
      <h2 className="text-xl sm:text-2xl font-bold text-transparent bg-gradient-to-r from-teal-700 to-cyan-600 bg-clip-text mb-4">💌 Входящие запросы</h2>
      {requests.length === 0 ? (
        <div className="text-center py-12 bg-white/40 rounded-2xl"><div className="text-5xl mb-3">💭</div><p className="text-gray-500">Нет новых запросов</p></div>
      ) : (
        <div className="space-y-3">
          {requests.map((req) => (
            <div key={req.id} className="card p-4 sm:p-5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 animate-fadeIn">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-400 to-cyan-500 flex items-center justify-center text-white font-bold">
                    {(req.fromUser?.firstName || req.fromUser?.name || '?').charAt(0)}
                  </div>
                  <div>
                    <p className="font-bold text-gray-800">{req.fromUser?.firstName || req.fromUser?.name}</p>
                    <p className="text-sm text-gray-500">{req.fromUser?.profession || req.fromUser?.role || 'Профессия не указана'}</p>
                  </div>
                </div>
                <div className="mt-2 flex flex-wrap gap-1">
                  {(req.fromUser?.hobbies || req.fromUser?.tags || []).slice(0, 3).map((tag: string) => (
                    <span key={tag} className="text-xs bg-teal-100 text-teal-700 px-2 py-0.5 rounded-full">{tag}</span>
                  ))}
                </div>
              </div>
              <div className="flex gap-2 w-full sm:w-auto">
                <button onClick={() => respond(req.id, 'accept')} className="btn-primary flex-1 sm:flex-none text-sm px-4 py-2 flex items-center gap-1">💚 Принять сейчас</button>
                <button onClick={() => respond(req.id, 'reject')} className="btn-secondary flex-1 sm:flex-none text-sm px-4 py-2 flex items-center gap-1">✖ Пропустить</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}