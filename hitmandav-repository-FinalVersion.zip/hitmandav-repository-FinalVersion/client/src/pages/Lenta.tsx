import { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import api from '../services/api';
import toast from 'react-hot-toast';

interface User {
  id: number;
  firstName?: string;
  middleName?: string;
  name?: string;
  profession?: string;
  role?: string;
  hobbies?: string[];
  tags?: string[];
  age?: number;
  contact?: string;
  commonTags?: number;
  likedMe?: boolean;
  iLiked?: boolean;
}

export default function Lenta() {
  const { eventId } = useParams();
  const userId = localStorage.getItem('currentUserId');
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [recommendedUsers, setRecommendedUsers] = useState<User[]>([]);
  const [myContacts, setMyContacts] = useState<User[]>([]);
  const [filterTag, setFilterTag] = useState('');
  const [view, setView] = useState<'all' | 'recommendations' | 'contacts'>('all');
  const [loading, setLoading] = useState(true);
  const [sentIds, setSentIds] = useState<Set<number>>(new Set());
  const [incomingRequests, setIncomingRequests] = useState<any[]>([]);
  const [showLikeModal, setShowLikeModal] = useState(false);
  const [currentLike, setCurrentLike] = useState<User | null>(null);
  const timersRef = useRef<Map<number, ReturnType<typeof setTimeout>>>(new Map());

  // Загрузка всех участников
  const fetchAllUsers = async () => {
    if (!eventId || !userId) return;
    try {
      const res = await api.get(`/users/event/${eventId}/registered?userId=${userId}`);
      setAllUsers(res.data);
    } catch (err) {
      console.error('Error fetching users:', err);
    }
  };

  // Загрузка рекомендаций
  const fetchRecommendations = async () => {
    if (!eventId || !userId) return;
    try {
      const res = await api.get(`/users/event/${eventId}/recommendations?userId=${userId}`);
      setRecommendedUsers(res.data);
    } catch (err) {
      console.error('Error fetching recommendations:', err);
    }
  };

  // Загрузка моих контактов (взаимные лайки)
  const fetchMyContacts = async () => {
    if (!userId) return;
    try {
      const res = await api.get(`/users/${userId}/contacts`);
      setMyContacts(res.data);
    } catch (err) {
      console.error('Error fetching contacts:', err);
    }
  };

  // Загрузка входящих запросов (кто меня лайкнул)
  const fetchIncomingRequests = async () => {
    if (!userId) return;
    try {
      const res = await api.get(`/users/${userId}/incoming-requests`);
      const pendingRequests = res.data.filter((r: any) => r.status === 'pending');
      setIncomingRequests(pendingRequests);
      
      // Если есть новые входящие запросы, показываем модалку
      if (pendingRequests.length > 0 && !showLikeModal) {
        const firstRequest = pendingRequests[0];
        setCurrentLike(firstRequest.fromUser);
        setShowLikeModal(true);
        // Запускаем автоответ
        autoRespondToLike(firstRequest.fromUser.id, Number(userId), firstRequest.fromUser.firstName || firstRequest.fromUser.name);
      }
    } catch (err) {
      console.error('Error fetching incoming requests:', err);
    }
  };

  // Автоответ через 5 секунд
  const autoRespondToLike = async (fromUserId: number, toUserId: number, fromName: string) => {
    if (timersRef.current.has(fromUserId)) return;
    
    const timerId = setTimeout(async () => {
      try {
        const interests = await api.get(`/users/${toUserId}/incoming-requests`);
        const pendingInterest = interests.data.find((i: any) => i.fromUserId === fromUserId);
        if (pendingInterest && pendingInterest.status === 'pending') {
          await api.put('/users/interest', { interestId: pendingInterest.id, action: 'accept' });
          toast.success(`💚 Взаимность! Контакт с ${fromName} открыт`);
          // Обновляем списки
          fetchAllUsers();
          fetchRecommendations();
          fetchMyContacts();
          fetchIncomingRequests();
          setShowLikeModal(false);
        }
        timersRef.current.delete(fromUserId);
      } catch (err) {
        console.error('Auto respond error:', err);
      }
    }, 5000);
    
    timersRef.current.set(fromUserId, timerId);
    toast(`⏳ Запрос от ${fromName} будет автоматически принят через 5 секунд`, { duration: 5000, icon: '🤖' });
  };

  // Отправка лайка
  const sendInterest = async (toUserId: number) => {
    if (sentIds.has(toUserId)) return;
    try {
      await api.post('/users/interest', { fromUserId: Number(userId), toUserId });
      setSentIds(prev => new Set(prev).add(toUserId));
      toast.success('💚 Запрос отправлен');
      // Обновляем списки
      fetchAllUsers();
      fetchRecommendations();
      fetchIncomingRequests();
    } catch (err: any) {
      if (err.response?.status === 409) {
        setSentIds(prev => new Set(prev).add(toUserId));
        toast.success('Запрос уже отправлен');
      } else {
        toast.error(err.response?.data?.error || 'Ошибка');
      }
    }
  };

  // Отзыв лайка
  const withdrawInterest = async (toUserId: number) => {
    try {
      await api.delete(`/users/interest/${toUserId}?fromUserId=${userId}`);
      setSentIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(toUserId);
        return newSet;
      });
      toast.success('Запрос отозван');
      fetchAllUsers();
      fetchRecommendations();
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Не удалось отозвать');
    }
  };

  // Ручной ответ на лайк (лайкнуть обратно)
  const handleLikeBack = async (likedUserId: number) => {
    if (timersRef.current.has(likedUserId)) {
      clearTimeout(timersRef.current.get(likedUserId)!);
      timersRef.current.delete(likedUserId);
    }
    await sendInterest(likedUserId);
    setShowLikeModal(false);
    fetchIncomingRequests();
    fetchMyContacts();
  };

  // Пропустить лайк
  const handleSkipLike = () => {
    if (currentLike && timersRef.current.has(currentLike.id)) {
      clearTimeout(timersRef.current.get(currentLike.id)!);
      timersRef.current.delete(currentLike.id);
    }
    setShowLikeModal(false);
  };

  // Загрузка всех данных при монтировании и смене вкладки
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([
        fetchAllUsers(),
        fetchRecommendations(),
        fetchMyContacts(),
        fetchIncomingRequests()
      ]);
      setLoading(false);
    };
    loadData();
    
    // Периодическая проверка новых входящих запросов
    const interval = setInterval(fetchIncomingRequests, 10000);
    return () => {
      clearInterval(interval);
      timersRef.current.forEach(timer => clearTimeout(timer));
      timersRef.current.clear();
    };
  }, [eventId, userId]);

  // Получение отображаемого списка в зависимости от вкладки
  const getDisplayedUsers = () => {
    switch (view) {
      case 'all':
        return allUsers;
      case 'recommendations':
        return recommendedUsers;
      case 'contacts':
        return myContacts;
      default:
        return allUsers;
    }
  };

  const displayedUsers = getDisplayedUsers();
  
  // Фильтрация по тегу
  const filtered = filterTag
    ? displayedUsers.filter(u => (u.hobbies || u.tags || []).some(t => t.toLowerCase().includes(filterTag.toLowerCase())))
    : displayedUsers;

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center"><div className="spinner"></div></div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-teal-50 via-cyan-50 to-white pb-20">
      {/* Модальное окно входящего лайка */}
      {showLikeModal && currentLike && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl">
            <div className="text-center mb-4">
              <div className="w-20 h-20 bg-gradient-to-br from-teal-400 to-cyan-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-3 shadow-lg">
                {(currentLike.firstName || currentLike.name || '?').charAt(0)}
              </div>
              <h3 className="text-xl font-bold text-teal-700">{currentLike.firstName || currentLike.name}</h3>
              <p className="text-sm text-gray-500">{currentLike.profession || currentLike.role}</p>
              <p className="text-xs text-gray-400 mt-2">{(currentLike.hobbies || currentLike.tags || []).join(', ') || 'Интересы не указаны'}</p>
              <p className="text-xs text-teal-500 mt-2 animate-pulse">⏳ Автоответ через 5 секунд...</p>
            </div>
            <div className="flex gap-3 mt-4">
              <button onClick={handleSkipLike} className="flex-1 py-3 rounded-xl border border-teal-200 text-teal-600 font-medium hover:bg-teal-50 transition-all">
                Пропустить
              </button>
              <button onClick={() => handleLikeBack(currentLike.id)} className="flex-1 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-500 text-white font-medium shadow-lg hover:shadow-xl transition-all">
                Лайкнуть обратно 💚
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="max-w-2xl mx-auto px-4 pt-4">
        {/* Табы */}
        <div className="flex gap-2 mb-6 p-1.5 bg-white/70 backdrop-blur-md rounded-2xl shadow-md">
          <button
            onClick={() => setView('all')}
            className={`flex-1 py-2.5 rounded-xl font-medium text-sm transition-all ${
              view === 'all' ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-white shadow-md' : 'text-teal-600 hover:bg-teal-50'
            }`}
          >
            👥 Участники
          </button>
          <button
            onClick={() => setView('recommendations')}
            className={`flex-1 py-2.5 rounded-xl font-medium text-sm transition-all ${
              view === 'recommendations' ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-white shadow-md' : 'text-teal-600 hover:bg-teal-50'
            }`}
          >
            ✨ Рекомендации
          </button>
          <button
            onClick={() => setView('contacts')}
            className={`flex-1 py-2.5 rounded-xl font-medium text-sm transition-all ${
              view === 'contacts' ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-white shadow-md' : 'text-teal-600 hover:bg-teal-50'
            }`}
          >
            🤝 Мои контакты
          </button>
        </div>

        {/* Поиск (только для вкладок "Участники" и "Рекомендации") */}
        {view !== 'contacts' && (
          <input
            type="text"
            placeholder="Поиск по тегу..."
            className="w-full px-4 py-3 rounded-xl bg-white/70 backdrop-blur-md focus:ring-2 focus:ring-teal-400 mb-4"
            value={filterTag}
            onChange={e => setFilterTag(e.target.value)}
          />
        )}

        {/* Контент */}
        {filtered.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-5xl mb-3">{view === 'contacts' ? '🤝' : '👥'}</div>
            <p className="text-gray-500">
              {view === 'contacts' ? 'Пока нет взаимных контактов' : 
               view === 'recommendations' ? 'Нет рекомендаций' : 'Участники не найдены'}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filtered.map((u, idx) => {
              const isMutual = (view === 'contacts') || (u.likedMe && u.iLiked);
              const isSent = u.iLiked || sentIds.has(u.id);
              const hasContact = u.contact && isMutual;
              
              return (
                <div key={u.id} className="user-card animate-fadeIn" style={{ animationDelay: `${idx * 50}ms` }}>
                  <div className="flex-1">
                    <h3 className="font-bold text-lg text-gray-800">
                      {u.firstName || u.name} {u.middleName || ''}
                      {u.age && <span className="text-teal-600 font-normal">, {u.age} лет</span>}
                      {u.profession && <span className="text-gray-500 text-sm font-normal"> • {u.profession}</span>}
                    </h3>
                    <p className="text-sm text-gray-600 mt-1">
                      {(u.hobbies || u.tags || []).join(', ') || 'интересы не указаны'}
                    </p>
                    {u.commonTags !== undefined && u.commonTags > 0 && (
                      <div className="mt-2 inline-block px-3 py-1 bg-gradient-to-r from-teal-100 to-cyan-100 rounded-full text-xs font-medium text-teal-700">
                        {u.commonTags} общих интересов
                      </div>
                    )}
                  </div>
                  {hasContact ? (
                    <div className="mt-3 pt-3 border-t border-teal-200/30">
                      <p className="text-teal-600 font-medium text-sm">📬 Контакт: {u.contact}</p>
                    </div>
                  ) : isSent ? (
                    <button onClick={() => withdrawInterest(u.id)} className="btn-secondary mt-3 w-full py-2">
                      Отозвать лайк ↩️
                    </button>
                  ) : (
                    <button onClick={() => sendInterest(u.id)} className="btn-primary mt-3 w-full py-2">
                      💚 Хочу познакомиться
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}