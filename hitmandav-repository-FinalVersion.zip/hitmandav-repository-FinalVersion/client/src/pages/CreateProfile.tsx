import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import api from '../services/api';
import { saveUserId, saveProfile as storeProfile } from '../services/userStorage';
import { UserPlus, Plus } from 'lucide-react';

const INTERESTS = ['frontend', 'backend', 'дизайн', 'AI', 'fintech', 'карьера', 'стартапы', 'аналитика'];

export default function CreateProfile() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: '',
    role: '',
    tags: [] as string[],
    contact: '',
    age: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isChecking, setIsChecking] = useState(true);
  const [touched, setTouched] = useState({ name: false, contact: false, tags: false });
  const [customTag, setCustomTag] = useState('');

  useEffect(() => {
    const userId = localStorage.getItem('currentUserId');
    if (userId) {
      api.get(`/users/${userId}`)
        .then(res => {
          const u = res.data;
          setForm({
            name: u.firstName || u.name || '',
            role: u.profession || u.role || '',
            tags: u.hobbies || u.tags || [],
            contact: u.contact || '',
            age: u.age ? String(u.age) : '',
          });
          storeProfile({
            name: u.firstName || u.name || '',
            role: u.profession || u.role || '',
            contact: u.contact || '',
            tags: u.hobbies || u.tags || [],
          });
        })
        .catch(() => {})
        .finally(() => setIsChecking(false));
    } else {
      setIsChecking(false);
    }
  }, []);

  const toggleTag = (tag: string) => {
    setForm(prev => {
      const newTags = prev.tags.includes(tag) 
        ? prev.tags.filter(t => t !== tag) 
        : [...prev.tags, tag];
      return { ...prev, tags: newTags.slice(0, 5) };
    });
    setTouched(prev => ({ ...prev, tags: true }));
  };

  const addCustomTag = () => {
    if (customTag.trim() && !form.tags.includes(customTag.trim()) && form.tags.length < 5) {
      setForm(prev => ({ ...prev, tags: [...prev.tags, customTag.trim()] }));
      setCustomTag('');
      setTouched(prev => ({ ...prev, tags: true }));
    }
  };

  const removeTag = (tag: string) => {
    setForm(prev => ({ ...prev, tags: prev.tags.filter(t => t !== tag) }));
    setTouched(prev => ({ ...prev, tags: true }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Валидация
    const newTouched = {
      name: !form.name.trim(),
      contact: !form.contact.trim(),
      tags: form.tags.length === 0,
    };
    setTouched(newTouched);
    
    if (!form.name.trim()) {
      toast.error('Введите имя');
      return;
    }
    if (form.tags.length === 0) {
      toast.error('Выберите хотя бы один тег');
      return;
    }
    if (!form.contact.trim()) {
      toast.error('Введите Telegram');
      return;
    }
    
    // Очистка и валидация Telegram
    let cleanContact = form.contact.trim();
    if (!cleanContact.startsWith('@')) {
      cleanContact = '@' + cleanContact;
    }
    const username = cleanContact.slice(1);
    if (!/^[a-zA-Z0-9_]+$/.test(username) || username.length < 3) {
      toast.error('Telegram: только буквы, цифры, _, минимум 3 символа');
      return;
    }
    
    setIsLoading(true);
    
    try {
      const payload = {
        firstName: form.name.trim(),
        profession: form.role.trim() || '',
        hobbies: form.tags,
        contact: cleanContact,
        age: form.age ? parseInt(form.age) : null,
      };
      
      const userId = localStorage.getItem('currentUserId');
      let res;
      
      if (userId) {
        // Обновление существующего профиля
        res = await api.put(`/users/profile/${userId}`, payload);
      } else {
        // Создание нового профиля
        res = await api.post('/users/profile', payload);
        if (res.data && res.data.id) {
          localStorage.setItem('currentUserId', String(res.data.id));
          if (saveUserId) saveUserId(String(res.data.id));
        }
      }
      
      if (res.data) {
        storeProfile({
          name: form.name.trim(),
          role: form.role.trim(),
          contact: cleanContact,
          tags: form.tags,
        });
        toast.success('Профиль сохранён!');
        navigate('/');
      } else {
        toast.error('Не удалось сохранить профиль');
      }
    } catch (err: any) {
      console.error('Profile save error:', err);
      const message = err.response?.data?.error || err.message || 'Ошибка сохранения';
      toast.error(message);
    } finally {
      setIsLoading(false);
    }
  };

  if (isChecking) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-6" style={{ background: 'linear-gradient(165deg, #e0f8f5 0%, #b8f0e9 25%, #a0eae3 50%, #88e3dd 75%, #6dd9d6 100%)' }}>
      <div className="card-modern w-full max-w-md p-5 sm:p-6">
        <h1 className="text-2xl font-bold text-transparent bg-gradient-to-r from-teal-700 to-cyan-600 bg-clip-text mb-4 text-center">Создать профиль</h1>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Имя */}
          <div>
            <label className="block text-sm font-semibold mb-2">Имя *</label>
            <input 
              type="text" 
              className={`input-field ${touched.name && !form.name.trim() ? 'input-error' : ''}`} 
              value={form.name} 
              onChange={e => {
                setForm({...form, name: e.target.value});
                setTouched({...touched, name: true});
              }} 
              required 
            />
            {touched.name && !form.name.trim() && <p className="text-red-500 text-sm mt-1">Введите имя</p>}
          </div>
          
          {/* Возраст */}
          <div>
            <label className="block text-sm font-semibold mb-2">Возраст</label>
            <input 
              type="number" 
              className="input-field" 
              value={form.age} 
              onChange={e => setForm({...form, age: e.target.value})} 
              min="1" 
            />
          </div>
          
          {/* Роль */}
          <div>
            <label className="block text-sm font-semibold mb-2">Роль или должность</label>
            <input 
              type="text" 
              placeholder="Product Manager, Frontend Developer..." 
              className="input-field" 
              value={form.role} 
              onChange={e => setForm({...form, role: e.target.value})} 
            />
          </div>
          
          {/* Теги */}
          <div>
            <label className="block text-sm font-semibold mb-2">Теги интересов ({form.tags.length}/5)</label>
            {touched.tags && form.tags.length === 0 && <p className="text-red-500 text-sm mb-1">Выберите хотя бы один тег</p>}
            <div className="flex flex-wrap gap-2">
              {INTERESTS.map(tag => (
                <button
                  type="button"
                  key={tag}
                  className={`btn-tag ${form.tags.includes(tag) ? 'btn-tag-active' : ''}`}
                  onClick={() => toggleTag(tag)}
                  disabled={!form.tags.includes(tag) && form.tags.length >= 5}
                >
                  {tag}
                </button>
              ))}
            </div>
            
            {/* Кастомные теги */}
            {form.tags.filter(t => !INTERESTS.includes(t)).length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {form.tags.filter(t => !INTERESTS.includes(t)).map(t => (
                  <span key={t} className="tag-selected">
                    {t}
                    <span onClick={() => removeTag(t)} className="ml-1 cursor-pointer">×</span>
                  </span>
                ))}
              </div>
            )}
            
            {/* Добавление кастомного тега */}
            <div className="flex gap-2 mt-2">
              <input
                type="text"
                placeholder="Добавить кастомный интерес"
                className="input-field flex-1"
                value={customTag}
                onChange={e => setCustomTag(e.target.value)}
                onKeyPress={e => e.key === 'Enter' && (e.preventDefault(), addCustomTag())}
                disabled={form.tags.length >= 5}
              />
              <button
                type="button"
                onClick={addCustomTag}
                disabled={form.tags.length >= 5 || !customTag.trim()}
                className="btn-add w-10 h-10"
              >
                <Plus size={16} />
              </button>
            </div>
          </div>
          
          {/* Telegram */}
          <div>
            <label className="block text-sm font-semibold mb-2">Telegram *</label>
            <input
              type="text"
              className={`input-field ${touched.contact && !form.contact.trim() ? 'input-error' : ''}`}
              value={form.contact}
              onChange={e => {
                let val = e.target.value;
                if (val && !val.startsWith('@')) val = '@' + val;
                const username = val.slice(1).replace(/[^a-zA-Z0-9_]/g, '');
                setForm({...form, contact: '@' + username});
                setTouched({...touched, contact: true});
              }}
              placeholder="@username"
              required
            />
            {touched.contact && !form.contact.trim() && <p className="text-red-500 text-sm mt-1">Введите Telegram</p>}
          </div>
          
          {/* Кнопка отправки */}
          <button 
            type="submit" 
            disabled={isLoading} 
            className="btn-primary w-full flex justify-center gap-2 py-3"
          >
            {isLoading ? <div className="spinner w-5 h-5 border-2"></div> : <UserPlus size={20} />}
            Сохранить профиль
          </button>
        </form>
      </div>
    </div>
  );
}