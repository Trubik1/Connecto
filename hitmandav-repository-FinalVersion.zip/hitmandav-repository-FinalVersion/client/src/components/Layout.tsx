import { Link } from 'react-router-dom';
import type { ReactNode } from 'react';

export default function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-mint-50 to-white">
      <header className="bg-mint-500 text-white shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
          <Link to="/" className="text-2xl font-bold">Connecto</Link>
          <nav className="space-x-4">
            <Link to="/create" className="hover:text-mint-100">Создать</Link>
            <Link to="/profile" className="hover:text-mint-100">Профиль</Link>
          </nav>
        </div>
      </header>
      <main className="flex-1 p-4">{children}</main>
    </div>
  );
}