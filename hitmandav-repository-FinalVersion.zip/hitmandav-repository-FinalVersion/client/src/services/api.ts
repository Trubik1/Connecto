import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

// Добавляем заголовок X-User-Id для авторизации
api.interceptors.request.use((config) => {
  const userId = localStorage.getItem('currentUserId');
  if (userId) {
    config.headers['X-User-Id'] = userId;
  }
  return config;
});

export default api;